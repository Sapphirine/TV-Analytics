.. _general_examples:

General examples
----------------

General-purpose and introductory examples for the scikit.
