from .spectral import SpectralCoclustering, SpectralBiclustering

__all__ = ['SpectralCoclustering',
           'SpectralBiclustering']
